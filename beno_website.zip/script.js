window.onload = () => {
  setTimeout(() => {
    const loader = document.getElementById('loading');
    if (loader) loader.style.display = 'none';
  }, 1000);
};

document.getElementById('darkModeToggle')?.addEventListener('click', () => {
  document.body.classList.toggle('dark');
});

function showToast(message) {
  const toast = document.createElement('div');
  toast.textContent = message;
  toast.style.cssText = `
    position: fixed; bottom: 20px; right: 20px;
    background: green; color: white; padding: 10px;
    border-radius: 8px; z-index: 9999;
  `;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 3000);
}
